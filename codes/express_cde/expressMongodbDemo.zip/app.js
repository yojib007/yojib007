var express = require('express');
var path = require('path');
var route = require('./routes/route');
var dbmodule = require('./routes/dbmodule');
var app= express();
// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');
app.use('/', route);
app.listen(3000);
console.log('server is running');
