var mongojs = require('mongojs');
var db = mongojs('db', ['users']);


//db.users.ensureIndex({email:1},{unique:true});

exports.saveUser = function(username,email) {  
	console.log('Saving user to mongo');
	db.users.save({"username":username, "email":email}, function(err, saved) {
  	if( err || !saved ) console.log("User not saved");
  	else console.log("User saved");
});
}

exports.authenticateUser = function(username,email,response) {
	db.users.find({"username":username,"email":email}, function(err, users) {
	console.log(users);
	   if( err || !users) 
      {
       console.log("Not authorized user"); 
        message="Failure";
       response.render('index',{title:'Hello',message:message});
       }
    else if(users.length==0) 
      {
        console.log("Not a valid user"); 
         message="failure";
         response.render('index',{title:'Hello',message:message});
      }
  else
    {
     console.log("Authorized user");
     console.log(users);
     console.log("Authorized user"); 
     message="Success";
     response.render('index',{title:'Hello',message:message});
	}
    }); }