var express = require('express');
var router = express.Router();
var dbmodule = require('./dbmodule');



router.get('/login',function(request,response){
	   var username=request.query.username;
       var email=request.query.email;
	   console.log(username + ' ' + email);
	   //console.log(request.body);
	   dbmodule.authenticateUser(username,email,response);		
            });
module.exports = router;